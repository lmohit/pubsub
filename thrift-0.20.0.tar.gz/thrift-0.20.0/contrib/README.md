Apache Thrift contrib folder
========================================

The code in the /contrib folder is not maintained on a regular basis and its purpose is mainly to serve 
as repository of (a) sample code what can be done with Thrift and (b) possibly helpfil utilities or other 
potentially useful stuff. 

You are of course free to provide patches for it, but other than that, the contrib stuff may or may not 
work for your purpose, environment or software version, as it does not part of regular testing procedures.

Below are some links (3rd-party sites) that lead you to some fairly good explanations of how it works.

  * https://drewdevault.com/2020/06/06/Add-a-contrib-directory.html
  * https://softwareengineering.stackexchange.com/questions/252053/whats-in-the-contrib-folder

