class Thrift {
	let version = "0.20.0"
}
